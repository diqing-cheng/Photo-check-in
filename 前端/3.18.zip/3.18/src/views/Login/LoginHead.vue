<template>
  <div class="head">
      <div class="icon">
      </div>
      <div class="name">人脸识别签到系统</div>
  </div>
</template>

<script>
export default {
    name: 'LoginHead',
}
</script>

<style>
.head{
    width:500px;
    height: 100%;
}
.icon{
    width:40%;
    height: 100%;
    background-color: black;
    float:left;
}
.name{
    float:left;
    width:60%;
    padding-top:10%;
    text-align: center;
    font-size: 30px;
}
</style>