<template>
  <div>
    <div class="login-head">
      登录
    </div>
    <div class="login-form">
      <el-form
        :model="ruleForm"
        :rules="rules"
        ref="ruleForm"
        label-width="100px"
        class="demo-ruleForm"
      >
        <el-form-item label="身份:" prop="role">
          <el-radio-group v-model="ruleForm.role">
            <el-radio label="我是学生"></el-radio>
            <el-radio label="我是老师"></el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item label="账号:" prop="id">
          <el-input v-model="ruleForm.id"></el-input>
        </el-form-item>
        <el-form-item label="密码:" prop="pass">
          <el-input
            type="password"
            v-model="ruleForm.pass"
            autocomplete="off"
          ></el-input>
        </el-form-item>
        <el-form-item>
          <el-button
            type="primary"
            @click="submitForm('ruleForm')"
            class="button-left"
            >登录</el-button
          >
          <el-button class="button-right"
            >注册</el-button
          >
        </el-form-item>
      </el-form>
    </div>
    <router-view></router-view>
  </div>
  
</template>

<script>
export default {
  data() {
    return {
      ruleForm: {
        name: "",
        pass: "",
        resource: "",
      },
      rules: {
        id: [
          { required: true, message: "请输入账号", trigger: "blur" },
        ],
        pass: [
          { required: true, message: "请输入密码", trigger: "blur" },
          { min: 6, message: "长度起码6个字符", trigger: "blur" },
        ],
        role: [
          { required: true, message: "请选择身份", trigger: "change" },
        ],
      },
    };
  },
  methods: {
    submitForm(formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          alert("submit!");
          
        this.$router.push('/Teacher')
        } else {
          console.log("error submit!!");
          return false;
        }
      });
    },
  },
};
</script>

<style>
.login-head {
  width: 100%;
  height: 40px;
  line-height: 40px;
  text-align: center;
  margin-bottom: 10px;
  color:rgb(26, 42, 63);
  font-family: "黑体";
  font-size: 25px;
  background-color: #2323;
}
.login-form {
  position: absolute;
  top: 60px;
  width: 90%;
  font-size: 30px;
}
.button-left {
  position: absolute;
  left: 20px;
}
.button-right {
  position: absolute;
  right: 40px;
}
</style>
