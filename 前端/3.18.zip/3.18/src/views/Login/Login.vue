<template>
  <div class="container">
    <header>
      <login-head></login-head>
    </header>
    <div class="login">
      <login-form></login-form>
    </div>
    <footer>
      版权所有© Copyright 2018-2022 西南大学网络工程小组   版本V-1.1.1
    </footer>
  </div>
</template>

<script>
import LoginForm from './LoginForm.vue';
import LoginHead from './LoginHead.vue';


export default {
  components: { LoginForm, LoginHead },
  name: "Login",
};
</script>

<style scoped>
.container{
  height: 100vh;
  width: 100%;
  background:#c1c9c555;
}
header{
  height: 100px;
  width:100%;
  background:#8696a7;
}
footer{
  position: absolute;
  bottom:0px;
  height: 70px;
  width:100%;
  background:#8696a7;
  color: rgb(250, 250, 250);
  text-align: center;
  line-height: 60px;
  font-size: 12px;
}
.login{
  position:absolute;
  text-align: center;
  top:30vh;
  right:20vw;
  width:450px;
  height: 300px;
  background:hsl(0, 0%, 100%);
}
</style>
